package pruebas;

public class prueba_para_cmd {

	public static void main(String[] args) {
		 System.out.println("¡Hola, mundo!");
	}

}
